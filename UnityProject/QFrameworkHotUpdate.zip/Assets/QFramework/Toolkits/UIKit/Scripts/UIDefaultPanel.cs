using System.Collections.Generic;
using System.Linq;

namespace QFramework
{
    public class UIDefaultPanel : UIPanel
    {

        
        protected override void OnInit(IUIData uiData = null)
        {
        }

        protected override void OnClose()
        {
        }
    }
}