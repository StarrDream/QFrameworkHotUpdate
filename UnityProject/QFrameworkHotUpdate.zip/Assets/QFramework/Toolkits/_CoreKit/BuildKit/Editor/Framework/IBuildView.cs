namespace QFramework
{
    public interface IBuildView
    {
        void Init();
        void OnGUI();
    }
}