using System.Collections.Generic;
public class AOTGenericReferences : UnityEngine.MonoBehaviour
{

	// {{ AOT assemblies
	public static readonly IReadOnlyList<string> PatchedAOTAssemblyList = new List<string>
	{
		"QFramework.CoreKit.dll",
		"UIKit.dll",
		"UnityEngine.CoreModule.dll",
		"mscorlib.dll",
	};
	// }}

	// {{ constraint implement type
	// }} 

	// {{ AOT generic types
	// QFramework.CustomObjectFactory<object>
	// QFramework.DefaultObjectFactory<object>
	// QFramework.IObjectFactory<object>
	// QFramework.MonoSingletonProperty<object>
	// QFramework.Pool<object>
	// QFramework.SafeObjectPool<object>
	// System.Action<object>
	// System.Collections.Generic.Stack.Enumerator<object>
	// System.Collections.Generic.Stack<object>
	// System.Func<object>
	// }}

	public void RefMethods()
	{
		// object QFramework.UIKit.OpenPanel<object>(QFramework.UILevel,QFramework.IUIData,string,string)
		// object UnityEngine.GameObject.AddComponent<object>()
	}
}