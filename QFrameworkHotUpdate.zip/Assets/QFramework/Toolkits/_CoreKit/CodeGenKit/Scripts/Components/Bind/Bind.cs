﻿/****************************************************************************
 * Copyright (c) 2017 ~ 2023 liangxie UNDER MIT LICENSE
 * 
 * https://qframework.cn
 * https://github.com/liangxiegame/QFramework
 ****************************************************************************/

using UnityEngine;

namespace QFramework
{
    [AddComponentMenu("QFramework/CodeGenKit/Bind")]
    public class Bind : AbstractBind
    {
    }
}