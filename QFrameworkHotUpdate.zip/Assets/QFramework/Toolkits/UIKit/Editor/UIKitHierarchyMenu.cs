﻿/****************************************************************************
 * Copyright (c) 2017 ~ 2021.8 liangxiegame MIT License
 * 
 * http://qframework.io
 * https://github.com/liangxiegame/QFramework
 ****************************************************************************/

using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace QFramework
{
    public static class UIKitHierarchyMenu
    {

    }
}